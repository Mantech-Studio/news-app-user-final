package com.example.news_app_user;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
